package edu.ecnu.admission.po;

public class ImageData {
    private byte[] data;

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}
    
}
